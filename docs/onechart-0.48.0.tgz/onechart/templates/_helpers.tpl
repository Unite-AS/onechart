{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "helm-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "helm-chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "helm-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "helm-chart.labels" -}}
helm.sh/chart: {{ include "helm-chart.chart" . }}
{{ include "helm-chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "helm-chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "helm-chart.name" . }}
app.kubernetes.io/instance: {{ template "robustName" .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "helm-chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "helm-chart.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create robustName that can be used as Kubernetes resource name, and as subdomain as well
\w – Latin letters, digits, underscore '_' .
\W – all but \w .
*/}}
{{- define "robustName" -}}
{{ regexReplaceAll "\\W+" . "-" | replace "_" "-" | lower | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "onechart.activeServiceName" -}}
{{- if and .Values.rollout .Values.rollout.enabled .Values.rollout.blueGreen .Values.rollout.blueGreen.activeService -}}
{{- include "robustName" .Values.rollout.blueGreen.activeService -}}
{{- else -}}
{{- include "robustName" .Release.Name -}}
{{- end -}}
{{- end }}

{{- define "onechart.previewServiceName" -}}
{{- if and .Values.rollout .Values.rollout.enabled .Values.rollout.blueGreen .Values.rollout.blueGreen.previewService -}}
{{- include "robustName" .Values.rollout.blueGreen.previewService -}}
{{- else -}}
{{- include "robustName" (printf "%s-preview" (include "robustName" .Release.Name)) -}}
{{- end -}}
{{- end }}

{{- define "onechart.ingressResourcesEnabled" -}}
{{- $ingressResourcesEnabled := true -}}
{{- if and .Values.ingress (hasKey .Values.ingress "resourcesEnabled") -}}
  {{- $ingressResourcesEnabled = .Values.ingress.resourcesEnabled -}}
{{- end -}}
{{- $ingressResourcesEnabled -}}
{{- end }}

{{- define "helm-chart.effectiveMinReplicas" -}}
{{- if and .Values.autoscale .Values.autoscale.enabled -}}
{{- .Values.autoscale.minReplicas | default 1 -}}
{{- else -}}
{{- .Values.replicas -}}
{{- end -}}
{{- end -}}
